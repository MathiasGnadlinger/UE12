package model;
/**
 * @author Mathias Gnadlinger
 * @version 12, 26.01.2021
 */
public enum ColorCode
{
    RED, GREEN, BLUE
}
